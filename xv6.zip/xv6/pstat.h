#ifndef _PSTAT_H
#define _PSTAT_H

#include "param.h"

struct pstat {

	int num_processes; // the PID of each process
	int pid[NPROC]; // the number of ticks each process has accumulated
	int ticks[NPROC];// the number of tickets this process has
	int tickets[NPROC];
};
#endif // _PSTAT_H_
